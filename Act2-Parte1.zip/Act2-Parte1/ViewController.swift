//
//  ViewController.swift
//  Act2-Parte1
//
//  Created by SAMUEL HERRERA on 26/01/24.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var ShowMessage: UILabel!
    @IBOutlet weak var Random: UILabel!
    @IBOutlet weak var Six: UITextField!
    @IBOutlet weak var Check: UIButton!


    override func viewDidLoad() {
        super.viewDidLoad()
        Six.delegate = self
    }
    
    func Reset () {
        ShowMessage.text = ""
        Random.text = "?"
    }
    
    @IBAction func Clicked(_ sender: UIButton) {
        let numeroAleatorio = Int.random(in: 1...6)
        
        // Verificar si el texto en Six es convertible a un número
        guard let userNumberText = Six.text, let userNumber = Int(userNumberText) else {
            // Mostrar un mensaje de error si no se puede convertir
            ShowMessage.text = "Ingresa un número válido."
            return
        }
        
        // Comparar el número ingresado con el número aleatorio
        if userNumber == numeroAleatorio {
            view.backgroundColor = UIColor.systemGreen
            ShowMessage.textColor = UIColor.black
            ShowMessage.text = "¡LE ATINASTE!"
        } else {
            view.backgroundColor = UIColor.systemRed
            ShowMessage.textColor = UIColor.white
            ShowMessage.text = "FALLASTE :/ Intenta Otra Vez"
        }
        
        // Mostrar el número aleatorio
        Random.text = "\(numeroAleatorio)"
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {

        let allowedCharacterSet = CharacterSet(charactersIn: "123456")
        let replacementStringCharacterSet = CharacterSet(charactersIn: string)
        let isNumeric = replacementStringCharacterSet.isSubset(of: allowedCharacterSet)
        

        let newLength = (textField.text?.count ?? 0) + string.count - range.length
        let isLengthValid = newLength <= 1
        
        return isNumeric && isLengthValid
    }
}

